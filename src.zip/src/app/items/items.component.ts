import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {
  type="any";
  @Output()
  status=new EventEmitter<any>();
  constructor() { }

  ngOnInit(): void {
  }
  backtocustomer(){}
  changeaddress(type:any){
    console.log(type)
   
    this.status.emit(this.type);
  }
 
    

}

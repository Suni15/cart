export default class Product{
    constructor(public productId:number,public productName:string,public cost:number,public discount:number,public image:string){
        
    }
}
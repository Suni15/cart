import { Component, OnInit } from '@angular/core';
import Order from '../Order';
import Product from '../Product';

import { UtilserviceService } from '../utilservice.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {
// @Input()
 user:String="kaushik";

  orders:any=[];
  ordersForDisplay:Order[]=this.orders

  totalCost:number=0;

  constructor(private util:UtilserviceService) { }

  ngOnInit(): void {
       
  let s= this.util.getOrders(this.user)
  s.subscribe((data)=>this.orders=data)
  this.ordersForDisplay.push(this.orders)
   console.log(this.ordersForDisplay)
  }

}
